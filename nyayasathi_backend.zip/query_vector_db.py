import os
import requests
import chromadb
from sentence_transformers import SentenceTransformer

# Use cache folder to reduce re-download size
model = SentenceTransformer("paraphrase-MiniLM-L6-v2", cache_folder="./model_cache")

# Load ChromaDB client
script_dir = os.path.dirname(os.path.abspath(__file__))
persist_dir = os.path.join(script_dir, "chroma_store")
chroma = chromadb.PersistentClient(path=persist_dir)
collection = chroma.get_collection("legal_docs")

def answer_query(query: str) -> str:
    print("📥 Processing query...")

    query_embedding = model.encode([query])[0].tolist()
    results = collection.query(query_embeddings=[query_embedding], n_results=2)
    top_docs = results.get("documents", [[]])[0]

    relevant_docs = [doc.strip() for doc in top_docs if len(doc.strip()) > 30]
    if not relevant_docs:
        return "❌ No relevant legal data found in the context."

    context = "\n\n".join(relevant_docs)
    prompt = f"Context:\n{context}\n\nQuestion: {query}"

    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    if not GROQ_API_KEY:
        return "❌ GROQ_API_KEY is not set in environment."

    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }

    body = {
        "model": "llama3-8b-8192",
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are a legal assistant. Use only the provided context to answer. "
                    "If context is insufficient, clearly say so."
                )
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    try:
        print("📡 Querying Groq API...")
        response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=body)

        if response.status_code != 200:
            return f"❌ Groq API Error: {response.status_code} - {response.text}"

        print("✅ Received response.")
        return response.json()["choices"][0]["message"]["content"]

    except Exception as e:
        return f"❌ Exception during Groq API call: {str(e)}"